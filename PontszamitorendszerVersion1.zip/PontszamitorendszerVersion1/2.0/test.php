<?php

// class Ember
// {
//     public $age;
//     function __construct($id)
//     {
//         $this->age=$id;
		
//     }
// }


// $ember=new Ember("100");
// $ember1=new Ember("200");
// $ember3=new Ember("60");
// $array=array();
// $array[]=$ember;
// $array[]=$ember1;
// $array[]=$ember3;


// //az algoritmust a tantárgyak sorba rndezésére használtam

// function bubble_Sort($targyak)
// {
// 	do
// 	{
// 		$csere = false;
// 		for( $i = 0, $c = count( $targyak ) - 1; $i < $c; $i++ )
// 		{
// 			if( $targyak[$i]->age > $targyak[$i + 1]->age )
// 			{
// 				list( $targyak[$i + 1], $targyak[$i] ) =
// 						array( $targyak[$i], $targyak[$i + 1] );
// 				$csere = true;
// 			}
// 		}
// 	}
// 	while( $csere );
// return $targyak;
// }

// $test=array();
// $test=bubble_Sort($array);
// foreach ($test as $key) {
//    echo $key->age;
//    echo "<br>";
// }



class Shape
{
	function __call($name,$arg)
	{
		if($name=="test")
		{
			switch(count($arg))
			{
				case 1:return 3.14*$arg[0]*$arg[0];
				case 2:return $arg[0]*$arg[1];
				
			}
		}
	}
	function testmethod()
	{
		echo $this->test(3);
	}
}

$circle=new Shape();

echo $circle->testmethod();
echo "<br>";
echo $circle->area(8,6);




