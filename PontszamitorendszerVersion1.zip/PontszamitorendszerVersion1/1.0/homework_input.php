<?php



































































class Szak
{
  public $egyetem;
  public $kar;
  public $szak;
  function __construct($egyetem,$kar,$szak) {
    $this->egyetem = $egyetem;
    $this->kar = $kar;
    $this->szak = $szak;
  }
  function getEgyetem()
  {
    return $this->egyetem;
  }
  function getKar()
  {
    return $this->kar;
  }
  function getSzak()
  {
    return $this->szak;
  }
}




class EretsegiEredmeny
{
    public $nev;
    public $tipus;
    public $eredmeny;
    function __construct($nev,$tipus,$eredmeny) 
    {
        $this->nev = $nev;
        $this->tipus = $tipus;
        $this->eredmeny = $eredmeny;
    }
    function getNev()
    {
        return $this->nev;
    }
    function getTipus()
    {
        return $this->tipus;
        
    }
    function getEredmeny()
    {
        return $this->eredmeny;
        
    }
}

class TobbletPont
{
    public $kategoria;
    public $tipus;
    public $nyelv;
    function __construct($kategoria,$tipus,$nyelv)
    {
        $this->kategoria=$kategoria;
        $this->tipus=$tipus;
        $this->nyelv=$nyelv;
        
    }
}




  










 function studentFactory($exampleData)
 {
    $szak=null;
    $eredmeny=null;
    $eredmenyek=array();
    $tobletPont=null;
    $tobbletPontok=array();



    foreach ($exampleData as $adattag => $ertek) 
    {
    foreach ($ertek as $alkulcs => $alertek) 
    {
        if (is_array($alertek))
         {
           // echo $alkulcs . " : <br>";
            
           if(isset($alertek['nev']))
           {
            $nev=$alertek['nev'];
            $tipus=$alertek['tipus'];
            $eredmeny=$alertek['eredmeny'];
            $eredmeny=new EretsegiEredmeny($nev,$tipus,$eredmeny);
            $eredmenyek[]=$eredmeny;
           }

            if(isset($alertek['kategoria']))
            {
                 $kategoria=$alertek['kategoria'];
                echo "<br>";
                $tipus=$alertek['tipus'];
                echo "<br>";
                $nyelv=$alertek['nyelv'];
                echo "<br>";
                $tobletPont=new TobbletPont($kategoria,$tipus,$nyelv);
                $tobbletPontok[]=$tobletPont;
               }
         }
          else
         {
             $egyetem=$ertek['egyetem'];
             $kar=$ertek['kar'];
             $szak=$ertek['szak'];
             $szak=new Szak($egyetem,$kar,$szak);
        }
    }
}
$student=new Student($szak,$eredmenyek,$tobbletPontok);
return $student;


 }









 
$exampleData = [
    'valasztott-szak' => [
        'egyetem' => 'ELTE',
        'kar' => 'IK',
        'szak' => 'Programtervező informatikus',
    ],
    'erettsegi-eredmenyek' => [
        [
            'nev' => 'magyar nyelv és irodalom',
            'tipus' => 'közép',
            'eredmeny' => '70%',
        ],
       
      
      
       
        [
            'nev' => 'történelem',
            'tipus' => 'közép',
            'eredmeny' => '80%',
        ],
        [
            'nev' => 'matematika',
            'tipus' => 'emelt',
            'eredmeny' => '90%',
        ],
        [
            'nev' => 'angol nyelv',
            'tipus' => 'közép',
            'eredmeny' => '94%',
        ],
        [
            'nev' => 'informatika',
            'tipus' => 'közép',
            'eredmeny' => '95%',
        ],
    ],
    'tobbletpontok' => [
        [
            'kategoria' => 'Nyelvvizsga',
            'tipus' => 'B2',
            'nyelv' => 'angol',
        ],
        [
            'kategoria' => 'Nyelvvizsga',
            'tipus' => 'C1',
            'nyelv' => 'német',
        ],
    ],
];






$student1=studentFactory($exampleData);
$student1->getEredmenyek();








// output: 476 (376 alappont + 100 többletpont)
$exampleData = [
    'valasztott-szak' => [
        'egyetem' => 'ELTE',
        'kar' => 'IK',
        'szak' => 'Programtervező informatikus',
    ],
    'erettsegi-eredmenyek' => [
        [
            'nev' => 'magyar nyelv és irodalom',
            'tipus' => 'közép',
            'eredmeny' => '70%',
        ],
        [
            'nev' => 'történelem',
            'tipus' => 'közép',
            'eredmeny' => '80%',
        ],
        [
            'nev' => 'matematika',
            'tipus' => 'emelt',
            'eredmeny' => '90%',
        ],
        [
            'nev' => 'angol nyelv',
            'tipus' => 'közép',
            'eredmeny' => '94%',
        ],
        [
            'nev' => 'informatika',
            'tipus' => 'közép',
            'eredmeny' => '95%',
        ],
        [
            'nev' => 'fizika',
            'tipus' => 'közép',
            'eredmeny' => '98%',
        ],
    ],
    'tobbletpontok' => [
        [
            'kategoria' => 'Nyelvvizsga',
            'tipus' => 'B2',
            'nyelv' => 'angol',
        ],
        [
            'kategoria' => 'Nyelvvizsga',
            'tipus' => 'C1',
            'nyelv' => 'német',
        ],
    ],
];




$student1=studentFactory($exampleData);
$student1->getEredmenyek();


// output: hiba, nem lehetséges a pontszámítás a kötelező érettségi tárgyak hiánya miatt
$exampleData2 = [
    'valasztott-szak' => [
        'egyetem' => 'ELTE',
        'kar' => 'IK',
        'szak' => 'Programtervező informatikus',
    ],
    'erettsegi-eredmenyek' => [
        [
            'nev' => 'matematika',
            'tipus' => 'emelt',
            'eredmeny' => '90%',
        ],
        [
            'nev' => 'angol nyelv',
            'tipus' => 'közép',
            'eredmeny' => '94%',
        ],
        [
            'nev' => 'informatika',
            'tipus' => 'közép',
            'eredmeny' => '95%',
        ],
    ],
    'tobbletpontok' => [
        [
            'kategoria' => 'Nyelvvizsga',
            'tipus' => 'B2',
            'nyelv' => 'angol',
        ],
        [
            'kategoria' => 'Nyelvvizsga',
            'tipus' => 'C1',
            'nyelv' => 'német',
        ],
    ],
];

// output: hiba, nem lehetséges a pontszámítás a magyar nyelv és irodalom tárgyból elért 20% alatti eredmény miatt
$exampleData3 = [
    'valasztott-szak' => [
        'egyetem' => 'ELTE',
        'kar' => 'IK',
        'szak' => 'Programtervező informatikus',
    ],
    'erettsegi-eredmenyek' => [
        [
            'nev' => 'magyar nyelv és irodalom',
            'tipus' => 'közép',
            'eredmeny' => '15%',
        ],
        [
            'nev' => 'történelem',
            'tipus' => 'közép',
            'eredmeny' => '80%',
        ],
        [
            'nev' => 'matematika',
            'tipus' => 'emelt',
            'eredmeny' => '90%',
        ],
        [
            'nev' => 'angol nyelv',
            'tipus' => 'közép',
            'eredmeny' => '94%',
        ],
        [
            'nev' => 'informatika',
            'tipus' => 'közép',
            'eredmeny' => '95%',
        ],
    ],
    'tobbletpontok' => [
        [
            'kategoria' => 'Nyelvvizsga',
            'tipus' => 'B2',
            'nyelv' => 'angol',
        ],
        [
            'kategoria' => 'Nyelvvizsga',
            'tipus' => 'C1',
            'nyelv' => 'német',
        ],
    ],
];






class Student
{
    public Szak $szak;
    public  $erettsegiEredmenyek;
    public  $tobbletPontok;
    function __construct(Szak $szak,$erettsegiEredmenyek,$tobbletPontok)
    {
        $this->szak=$szak;
        $this->erettsegiEredmenyek=$erettsegiEredmenyek;
        $this->tobbletPontok=$tobbletPontok;
    }
    function getEredmenyek()
    {
        if($this->get_szak()->egyetem=="ELTE" && $this->get_szak()->kar=="IK")
        {
          $this->ELTEIK();
        }
        else if($this->get_szak()->egyetem=="PPKE" && $this->get_szak()->kar=="BTK")
        {
            $this->PPKEBTK();
        }

    }
    function get_szak() {
        return $this->szak;
      }
    function isCanCalculat()
    {
             
            $isCanCalculate=false;
            $isMagyar=false;
            $isHyst=false;
            $isMath=false;
            $isPass=true;
           
            for ($i=0; $i <count($this->erettsegiEredmenyek); $i++)
            { 
                $eredmenynev=$this->erettsegiEredmenyek[$i]->nev;
                $eredmenyPercent=$this->erettsegiEredmenyek[$i]->eredmeny;
                if($eredmenynev=="magyar nyelv és irodalom")
                {
                    $isMagyar=true;
                }
                if($eredmenynev="történelem")
                {
                    $isHyst=true;
                }
                if($eredmenynev="matematika")
                {
                    $isMath=true;
                }
                if((int)$eredmenyPercent<20)
                {
                        $isPass=false;
                        echo "hiba, nem lehetséges a pontszámítás a magyar nyelv és irodalom tárgyból elért 20% alatti eredmény miatt";
                        
                }
            }
            
            if($isMagyar && $isMath && $isHyst && $isPass)
            {
                $isCanCalculate=true;
            }

            else if(!($isMagyar) || !($isMath) || !($isHyst))
            {
                echo "hiba, nem lehetséges a pontszámítás a kötelező érettségi tárgyak hiánya miatt";
            }
           
            return $isCanCalculate;

    }



    function bubbleSort($targyak)
    {
           
     

            do
            {
                $csere=false;
                for( $i = 0, $c = count($targyak) - 1; $i < $c; $i++ )
                {

                    if((int)$targyak[$i]->eredmeny<(int)$targyak[$i + 1]->eredmeny )
                    {
                        list($targyak[$i + 1], $targyak[$i] ) =
                                array( $targyak[$i], $targyak[$i + 1] );
                        $csere = true;
                    }
                }
            }
            while($csere);
        return $targyak[0];
    }

   
    function ELTEIK()
    {  
        
        
        
        if($this->isCanCalculat())
        {

            $alappont=0;
            $valaszthatoTargyak=array();
            $tobbletPont=0;
           
            for ($i=0; $i <count($this->erettsegiEredmenyek); $i++)
            { 
                $eredmenynev=$this->erettsegiEredmenyek[$i]->nev;
                $eredmenyPercent=$this->erettsegiEredmenyek[$i]->eredmeny;
                $aktualisEredmeny=$this->erettsegiEredmenyek[$i];
                if($aktualisEredmeny->tipus=="emelt")
                {
                  $tobbletPont+=50;
                }
                
                if($eredmenynev=="matematika")
                {
                   $alappont+=(int)$eredmenyPercent;
                }
                if($eredmenynev=="biológia")
                {
                    $valaszthatoTargyak[]=$aktualisEredmeny;
                }
                if($eredmenynev=="informatika")
                {
                    $valaszthatoTargyak[]=$aktualisEredmeny;
                }
                if($eredmenynev=="fizika")
                {
                    $valaszthatoTargyak[]=$aktualisEredmeny;
                }
                if($eredmenynev=="kémia")
                {
                    $valaszthatoTargyak[]=$aktualisEredmeny;
                }
         
            }
            $legnagyobbValaszthato=$this->bubbleSort($valaszthatoTargyak);
            $alappont+=(int)$legnagyobbValaszthato->eredmeny;
           $alappont=$alappont*2;
           



           for ($i=0; $i <count($this->tobbletPontok); $i++)
           {
              $aktualisTobbletPont=$this->tobbletPontok[$i];
              if($aktualisTobbletPont->tipus=="B2")
              {
                $tobbletPont+=28;
              }
              if($aktualisTobbletPont->tipus=="C1")
              {
                $tobbletPont+=40;
              }

           
           }
           if($tobbletPont>100)
           {
            $tobbletPont=100;
           }
           
           echo $tobbletPont+$alappont;
           
            
          
        }


    }





    function PPKEBTK()
    {  
        
        
        
        if($this->isCanCalculat())
        {

            $alappont=0;
            $valaszthatoTargyak=array();
            $tobbletPont=0;
           
            for ($i=0; $i <count($this->erettsegiEredmenyek); $i++)
            { 
                $eredmenynev=$this->erettsegiEredmenyek[$i]->nev;
                $eredmenyPercent=$this->erettsegiEredmenyek[$i]->eredmeny;
                $aktualisEredmeny=$this->erettsegiEredmenyek[$i];
                if($aktualisEredmeny->tipus=="emelt")
                {
                  $tobbletPont+=50;
                }
                
                if($eredmenynev=="angol" && $aktualisEredmeny->getTipus=="emelt")
                {
                   $alappont+=(int)$eredmenyPercent;
                }
                if($eredmenynev=="biológia")
                {
                    $valaszthatoTargyak[]=$aktualisEredmeny;
                }
                if($eredmenynev=="francia")
                {
                    $valaszthatoTargyak[]=$aktualisEredmeny;
                }
                if($eredmenynev=="német")
                {
                    $valaszthatoTargyak[]=$aktualisEredmeny;
                }
                if($eredmenynev=="orosz")
                {
                    $valaszthatoTargyak[]=$aktualisEredmeny;
                }
                if($eredmenynev=="olasz")
                {
                    $valaszthatoTargyak[]=$aktualisEredmeny;
                }
                if($eredmenynev=="történelem")
                {
                    $valaszthatoTargyak[]=$aktualisEredmeny;
                }
         
            }
            $legnagyobbValaszthato=$this->bubbleSort($valaszthatoTargyak);
            $alappont+=(int)$legnagyobbValaszthato->eredmeny;
           $alappont=$alappont*2;
           



           for ($i=0; $i <count($this->tobbletPontok); $i++)
           {
              $aktualisTobbletPont=$this->tobbletPontok[$i];
              if($aktualisTobbletPont->tipus=="B2")
              {
                $tobbletPont+=28;
              }
              if($aktualisTobbletPont->tipus=="C1")
              {
                $tobbletPont+=40;
              }

           
           }
           if($tobbletPont>100)
           {
            $tobbletPont=100;
           }
           
           echo $tobbletPont+$alappont;
           
            
          
        }


    }

   

   




    function getSzak()
    {
        return $this->szak;
    }
}
  





 $student2=studentFactory($exampleData2);
 $student2->getEredmenyek();

 $student3=studentFactory($exampleData3);
 $student3->getEredmenyek();






























